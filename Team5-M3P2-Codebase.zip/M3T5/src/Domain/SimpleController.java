package Domain;

public class SimpleController {

}
