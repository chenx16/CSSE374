package Domain;

import java.util.ArrayList;

import Data.CondimentDecorator;

abstract class OrderFactory {


	public AbstractOrder OrderCoffee(int orderID, String address, String zip, String drinktype,
			ArrayList<CondimentDecorator> condiments) {
		// TODO Auto-generated method stub
		return null;
	}
}
