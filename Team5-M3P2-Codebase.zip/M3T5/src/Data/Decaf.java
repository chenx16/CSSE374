package Data;

public class Decaf extends DrinkType {
	public Decaf() {
		recipe = "Drink Type: Decaf";
		}

}
