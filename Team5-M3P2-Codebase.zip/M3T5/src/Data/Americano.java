package Data;

public class Americano extends DrinkType {
	public Americano() {
		recipe = "Drink Type: Americano";
		}
		
		


}
