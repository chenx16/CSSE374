package Domain;

public class AdvancedProduce implements produceDrinkBehavior {

	@Override
	public void producedrink() {
		// TODO Auto-generated method stub
		System.out.println("Use Simple Coffee Machine to product drink");
	}
		
}
