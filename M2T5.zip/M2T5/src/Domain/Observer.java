package Domain;

public interface Observer {	
	public void update();
}
