package Domain;

public interface produceDrinkBehavior {
	public void producedrink();
}
