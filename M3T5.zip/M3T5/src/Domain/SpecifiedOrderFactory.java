package Domain;

public class SpecifiedOrderFactory {

}
