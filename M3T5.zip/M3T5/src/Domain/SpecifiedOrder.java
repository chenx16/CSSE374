package Domain;

public class SpecifiedOrder extends AbstractOrder{

	@Override
	public double makeCoffee() {
		// TODO Auto-generated method stub
		return 0;
	}



}
