package Domain;

public class SpecifiedOrder {

}
