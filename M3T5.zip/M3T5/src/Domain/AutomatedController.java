package Domain;

public class AutomatedController {

}
