package Domain;

public class RecipeOrder {

}
