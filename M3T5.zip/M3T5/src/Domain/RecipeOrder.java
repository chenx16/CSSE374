package Domain;

public class RecipeOrder extends AbstractOrder{

	@Override
	public double makeCoffee() {
		// TODO Auto-generated method stub
		return 0;
	}



}
