package Domain;

public class AbstractOrder {

}
