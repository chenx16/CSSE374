import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		 while(true) {
			   System.out.println("--------------------------------------------");
			   System.out.println("System: Start order");

			   Scanner scanner = new Scanner(System.in);
				 System.out.println("Simple Machine Press 1");
				   System.out.println("Advanced Machine Press 2");

				   System.out.println("Your coffee has been prepared with your desired options.");
			   

			}
	}
	


}
