package Data;

public class IngrendientDecorator {

}
