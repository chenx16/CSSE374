package Data;



public abstract class IngrendientDecorator extends DrinkType{

	public abstract String getRecipe();
	
}
