package Data;

public class Milk {

}
