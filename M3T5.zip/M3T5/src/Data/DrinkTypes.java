package Data;

public class DrinkTypes {

}
