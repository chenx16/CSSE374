package Data;

public class PumpkinSpiceDrink extends DrinkType {
	public PumpkinSpiceDrink() {
		recipe = "Drink Type: PumpkinSpice";
		}

}
