package Data;

public class Coffee {

}
