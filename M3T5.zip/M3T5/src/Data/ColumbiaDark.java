package Data;

public class ColumbiaDark extends DrinkType {
		public ColumbiaDark() {
		recipe = "Drink Type: Columbia Dark";
		}
		
		


}
