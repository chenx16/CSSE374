package Data;

public abstract class CondimentDecorator extends DrinkType{

	public abstract String getRecipe();

}
