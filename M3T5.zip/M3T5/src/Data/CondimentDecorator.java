package Data;

public class CondimentDecorator {

}
