package Data;

public class Sugar {

}
