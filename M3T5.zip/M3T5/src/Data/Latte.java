package Data;

public class Latte extends DrinkType {
	public Latte() {
		recipe = "Drink Type: Latte";
		}
		


}