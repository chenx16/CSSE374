package Data;

public class Latte {

}
