package Data;

public class WhippedCream {

}
