package Data;

public class Expresso extends DrinkType {
	public Expresso() {
		recipe = "Drink Type: Expresso";
		}

}
