package Data;

public abstract class DrinkType {
	String recipe;

	public String getRecipe() {
		return recipe;
		}

}
