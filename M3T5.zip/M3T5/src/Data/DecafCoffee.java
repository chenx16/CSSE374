package Data;

public class DecafCoffee {

}
