package Data;

public class SoyMilk {

}
